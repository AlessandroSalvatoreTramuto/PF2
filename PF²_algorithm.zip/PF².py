# =============================================================================
# PHASE FOLDING & PERIOD FINDING ALGORTIHM (PF^2) - GENERALIZED PIPELINE
# AUTHORs: ALESSANDRO SALVATORE TRAMUTO, ROSARIA (SARA) BONITO, LAURA VENUTI, MARCO MICELI
# YEAR: 2026
# 
# DESCRIPTION:
# This script processes time-series photometric data to find stellar rotation
# periods. It performs moving-average detrending, runs a Lomb-Scargle periodogram
# with full permutation arrays to establish rigorous n-sigma noise floors and False 
# Alarm Probabilities (FAP). It then empirically finds periodogram peaks and ranks 
# them using 7 statistical and morphological metrics (String Length, variance, 
# smoothness, scatter, etc.) to distinguish the true period from harmonics/aliases.
# Optionally, it generates interactive HTML phase-folded plots via Bokeh.
# =============================================================================


import pandas as pd
import numpy as np
import numpy.random
from astropy.timeseries import LombScargle
from astropy.table import Table
from scipy.stats import rankdata
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter, find_peaks
import warnings
from bisect import bisect_left, bisect_right
import time
import multiprocessing
import os
from tqdm import tqdm
import sys
from io import StringIO

# --- BOKEH IMPORTS ---
from bokeh.plotting import figure, output_file, save
from bokeh.layouts import column
from bokeh.models import Span, Div

# IMPORT CONFIGURATION
try:
    import config as cfg
except ImportError:
    print("❌ Critical Error: 'config.py' not found in the current directory.")
    sys.exit(1)

# ============================
# UTILITY FUNCTIONS
# ============================

def estimate_effective_sampling(times, percentile=10):
    """Estimates the typical sampling cadence, ignoring large gaps."""
    if len(times) < 2: return 0.1
    gaps = np.diff(np.sort(times))
    intra_night_gaps = gaps[gaps < 0.5]
    if len(intra_night_gaps) == 0:
        return np.percentile(gaps, percentile)
    return np.median(intra_night_gaps)

def calculate_period_fwhm(freqs, power, target_period):
    """Estimates the uncertainty of the period using the peak FWHM."""
    if np.isnan(target_period) or target_period <= 0 or len(freqs) == 0:
        return np.nan
    target_freq = 1.0 / target_period
    idx_peak = np.argmin(np.abs(freqs - target_freq))
    peak_power = power[idx_peak]
    half_max = peak_power / 2.0
    
    if idx_peak == 0 or idx_peak == len(power) - 1: return np.nan
    
    left_idx = idx_peak
    while left_idx > 0 and power[left_idx] > half_max: left_idx -= 1
    if power[left_idx] <= half_max:
        f1, p1 = freqs[left_idx], power[left_idx]
        f2, p2 = freqs[left_idx+1], power[left_idx+1]
        f_left = f1 + (half_max - p1) * (f2 - f1) / (p2 - p1) if p2 != p1 else f1
    else:
        f_left = freqs[0] 
        
    right_idx = idx_peak
    while right_idx < len(power) - 1 and power[right_idx] > half_max: right_idx += 1
    if power[right_idx] <= half_max:
        f1, p1 = freqs[right_idx-1], power[right_idx-1]
        f2, p2 = freqs[right_idx], power[right_idx]
        f_right = f1 + (half_max - p1) * (f2 - f1) / (p2 - p1) if p2 != p1 else f2
    else:
        f_right = freqs[-1]
        
    f_width = f_right - f_left
    period_error = (target_period**2) * f_width
    return period_error

def moving_average_detrend(times, mags, window_days):
    """
    Removes long-term trends using a moving average window.
    Crucial for separating rotation from long-term stellar evolution/noise.
    """
    if len(times) == 0: return np.array([]), np.array([])
    sort_idx = np.argsort(times)
    times_sorted, mags_sorted = times[sort_idx], mags[sort_idx]
    trend = np.full_like(mags_sorted, np.nan)
    half_window = window_days / 2.0
    
    for i in range(len(times_sorted)):
        t_center = times_sorted[i]
        idx_start = bisect_left(times_sorted, t_center - half_window)
        idx_end = bisect_right(times_sorted, t_center + half_window)
        mags_in_window = mags_sorted[idx_start:idx_end]
        finite_mags = mags_in_window[np.isfinite(mags_in_window)]
        if len(finite_mags) > 0: trend[i] = np.mean(finite_mags)
        
    trend_original_order = np.full_like(mags, np.nan)
    trend_original_order[sort_idx] = trend
    mags_detrended = mags - trend_original_order
    return mags_detrended, trend_original_order

# ============================
# METRICS & QUALITY CHECKS
# ============================

def evaluate_period_quality(times, mags, period, n_bins=20):
    """
    Calculates various metrics (String Length, Binned Variance, etc.)
    to evaluate how well the data folds with the given period.
    """
    if len(times) == 0 or np.isnan(period) or period <= 0:
        return {k: np.nan for k in ['string_length', 'binned_variance', 'wrap_discontinuity', 'smoothness', 'within_bin_scatter', 'sharpness']}
    
    phase = (times % period) / period
    sorted_idx = np.argsort(phase)
    sorted_phase, sorted_mags = phase[sorted_idx], mags[sorted_idx]
    
    if len(sorted_phase) < 2:
        return {k: np.nan for k in ['string_length', 'binned_variance', 'wrap_discontinuity', 'smoothness', 'within_bin_scatter', 'sharpness']}
        
    phase_diffs, mag_diffs = np.diff(sorted_phase), np.diff(sorted_mags)
    phase_diffs[phase_diffs <= 0] = 1e-9
    valid_diffs = np.isfinite(phase_diffs) & np.isfinite(mag_diffs)
    normalized_string_length = np.sum(np.sqrt(phase_diffs[valid_diffs]**2 + mag_diffs[valid_diffs]**2)) / len(times) if np.any(valid_diffs) else np.nan
    
    n_edge = min(5, len(sorted_mags) // 10)
    wrap_diff = np.nan
    if n_edge > 0:
        start_mags, end_mags = sorted_mags[:n_edge], sorted_mags[-n_edge:]
        start_mean = np.mean(start_mags[np.isfinite(start_mags)]) if np.any(np.isfinite(start_mags)) else np.nan
        end_mean = np.mean(end_mags[np.isfinite(end_mags)]) if np.any(np.isfinite(end_mags)) else np.nan
        if not (np.isnan(start_mean) or np.isnan(end_mean)): wrap_diff = np.abs(end_mean - start_mean)
        
    bins = np.linspace(0, 1, n_bins + 1)
    bin_means, bin_stds = [], []
    for i in range(n_bins):
        mask = (sorted_phase >= bins[i]) & (sorted_phase < bins[i+1])
        mags_in_bin = sorted_mags[mask]
        finite_mags_in_bin = mags_in_bin[np.isfinite(mags_in_bin)]
        if len(finite_mags_in_bin) > 2:
            bin_means.append(np.mean(finite_mags_in_bin))
            bin_stds.append(np.std(finite_mags_in_bin))
        else:
            bin_means.append(np.nan)
            bin_stds.append(np.nan)
            
    valid_bin_means = np.array(bin_means)[np.isfinite(bin_means)]
    valid_bin_stds = np.array(bin_stds)[np.isfinite(bin_stds)]
    
    binned_variance, smoothness, within_bin_scatter = 0, 0, np.std(mags[np.isfinite(mags)]) if np.any(np.isfinite(mags)) else 0.0
    if len(valid_bin_means) > 1:
        binned_variance = np.var(valid_bin_means)
        if len(valid_bin_means) > 2: smoothness = np.std(np.diff(valid_bin_means))
        if len(valid_bin_stds) > 0: within_bin_scatter = np.mean(valid_bin_stds)
        
    sharpness = 0
    if len(valid_bin_means) > 0:
        median_mag = np.median(valid_bin_means)
        finite_diffs = np.abs(valid_bin_means - median_mag)
        mad = np.median(finite_diffs) if len(finite_diffs) > 0 else 0
        if mad > 0: sharpness = np.sum(finite_diffs > 2 * mad) / n_bins
        
    return {
        'string_length': float(normalized_string_length) if np.isfinite(normalized_string_length) else np.nan,
        'binned_variance': float(binned_variance) if np.isfinite(binned_variance) else np.nan,
        'wrap_discontinuity': float(wrap_diff) if np.isfinite(wrap_diff) else np.nan,
        'smoothness': float(smoothness) if np.isfinite(smoothness) else np.nan,
        'within_bin_scatter': float(within_bin_scatter) if np.isfinite(within_bin_scatter) else np.nan,
        'sharpness': float(sharpness) if np.isfinite(sharpness) else np.nan
    }

def compute_phase_dispersion_from_smooth(times, mags, period, window_fraction=0.05):
    """Calculates residual dispersion from a smoothed phase curve."""
    if len(times) < 10 or np.isnan(period) or period <= 0: return np.nan
    phase = (times % period) / period
    sort_idx = np.argsort(phase)
    phase_sorted, mags_sorted = phase[sort_idx], mags[sort_idx]
    
    valid_mask = np.isfinite(phase_sorted) & np.isfinite(mags_sorted)
    phase_sorted, mags_sorted = phase_sorted[valid_mask], mags_sorted[valid_mask]
    if len(phase_sorted) < 10: return np.nan
    
    phase_grid = np.linspace(0, 1, 200)
    phase_extended = np.concatenate([phase_sorted - 1, phase_sorted, phase_sorted + 1])
    mags_extended = np.concatenate([mags_sorted, mags_sorted, mags_sorted])
    
    try:
        interp_func = interp1d(phase_extended, mags_extended, kind='linear', bounds_error=False, fill_value='extrapolate')
        mags_grid = interp_func(phase_grid)
    except ValueError: return np.nan
    
    mags_grid = np.nan_to_num(mags_grid, nan=np.nanmedian(mags_grid) if np.any(np.isfinite(mags_grid)) else 0.0)
    polyorder = 3
    window_points = max(5, int(window_fraction * len(phase_grid)))
    if window_points <= polyorder: window_points = polyorder + 2
    if window_points % 2 == 0: window_points += 1
    
    try:
        mags_smooth = savgol_filter(mags_grid, window_length=window_points, polyorder=polyorder, mode='wrap')
    except ValueError:
        win_uniform = max(3, int(window_fraction * len(phase_grid)))
        padded_mags = np.pad(mags_grid, (win_uniform//2, win_uniform - 1 - win_uniform//2), mode='wrap')
        mags_smooth = np.convolve(padded_mags, np.ones(win_uniform)/win_uniform, mode='valid')
        if len(mags_smooth) != len(phase_grid):
             interp_smooth = interp1d(np.linspace(0, 1, len(mags_smooth)), mags_smooth, bounds_error=False, fill_value="extrapolate")
             mags_smooth = interp_smooth(phase_grid)
             
    mags_smooth = np.nan_to_num(mags_smooth, nan=np.nanmedian(mags_smooth) if np.any(np.isfinite(mags_smooth)) else 0.0)
    try:
        smooth_func = interp1d(phase_grid, mags_smooth, kind='linear', bounds_error=False, fill_value='extrapolate')
        mags_smooth_at_data = smooth_func(phase_sorted)
    except ValueError: return np.nan
    
    residuals = mags_sorted - mags_smooth_at_data
    dispersion = np.std(residuals[np.isfinite(residuals)])
    signal_amplitude = np.ptp(mags_smooth)
    if signal_amplitude < 1e-6 or np.isnan(dispersion): return np.nan
    return dispersion / signal_amplitude

def check_multiple_peaks_alert(times, mags, period, freqs, raw_power, noise_mean, noise_std, photometric_error_threshold):
    """
    Checks 2P, 3P, 4P etc. to see if they fit better than P.
    Applies the Noise Floor logic to avoid false positives on tiny improvements.
    """
    if np.isnan(period) or period <= 0: return False, None, 0.0, np.nan, np.nan, None, {}
    
    print(f"\n🔬 Starting Multiple Peaks check (SNR Filter > {cfg.SIGMA_THRESHOLD}):")
    
    baseline = times.max() - times.min()
    max_period = 0.75 * baseline
    disp_P = compute_phase_dispersion_from_smooth(times, mags, period)
    if np.isnan(disp_P): return False, None, 0.0, disp_P, np.nan, None, {}
    dispersions = {'P': disp_P}
    
    for mult in [2, 3, 4, 5, 6]:
        test_period = period * mult
        if np.isnan(test_period) or test_period <= 0 or test_period > max_period:
            dispersions[f'{mult}P'] = np.nan
            continue
            
        test_freq = 1.0 / test_period
        is_significant = False
        n_sigma = 0.0
        
        if freqs.size > 0 and test_freq >= freqs.min() and test_freq <= freqs.max():
            idx = np.argmin(np.abs(freqs - test_freq))
            if idx < len(raw_power):
                p_val = raw_power[idx]
                mean_val = noise_mean[idx]
                std_val = noise_std[idx]
                n_sigma = (p_val - mean_val) / std_val if std_val > 0 else 0.0
                if n_sigma >= cfg.SIGMA_THRESHOLD: is_significant = True
                
        if not is_significant:
            print(f"            - {mult}P ({test_period:.4f}d) discarded (SNR={n_sigma:.2f} < {cfg.SIGMA_THRESHOLD})")
            dispersions[f'{mult}P'] = np.nan
            continue
            
        disp_mult = compute_phase_dispersion_from_smooth(times, mags, test_period)
        dispersions[f'{mult}P'] = disp_mult
        print(f"            - {mult}P ({test_period:.4f}d) analyzed (SNR={n_sigma:.2f}, Disp={disp_mult:.4f})")
        
    valid_dispersions = {k: v for k, v in dispersions.items() if not np.isnan(v)}
    
    if len(valid_dispersions) <= 1: 
        print("✓ Multiple peaks check: Not enough valid multiples found.")
        return False, None, 0.0, disp_P, np.nan, None, dispersions

    best_key = min(valid_dispersions, key=valid_dispersions.get)
    best_dispersion = valid_dispersions[best_key]
    disp_diff = disp_P - best_dispersion
    
    print(f"✓ Multiple peaks check: Best={best_key} (Diff={disp_diff:.6f}, Threshold={photometric_error_threshold:.6f})")

    # Critical: Apply Noise Floor
    if disp_diff <= cfg.NOISE_FLOOR_MAG:
        return False, None, disp_diff, disp_P, best_dispersion, None, dispersions

    if best_key == 'P': return False, None, disp_diff, disp_P, best_dispersion, None, dispersions
    
    multiplier = int(best_key.replace('P', ''))
    suggested_period = period * multiplier
    alert = disp_diff > photometric_error_threshold
    
    if alert:
        print(f"⚠️ ALERT: Significant improvement with {best_key}!")
        
    return alert, suggested_period, disp_diff, disp_P, best_dispersion, multiplier, dispersions

def select_best_period_by_ranking(times, mags, base_period, freqs, raw_power, noise_mean, noise_std):
    """
    The Core Ranking Logic.
    Selects candidates based SOLELY on real periodogram peaks > SIGMA_THRESHOLD.
    """
    if np.isnan(base_period) or base_period <= 0: return []
    
    baseline = times.max() - times.min()
    max_allowed_period = 0.6 * baseline
    candidates = []
    
    # 1. Find ALL local peaks
    peak_indices, _ = find_peaks(raw_power, distance=5)
    if len(peak_indices) == 0: return []

    # 2. Filter significant peaks
    peak_powers = raw_power[peak_indices]
    peak_means = noise_mean[peak_indices]
    peak_stds = noise_std[peak_indices]
    peak_stds[peak_stds <= 0] = 1.0 
    peak_n_sigmas = (peak_powers - peak_means) / peak_stds
    
    valid_mask = peak_n_sigmas >= cfg.SIGMA_THRESHOLD
    valid_indices = peak_indices[valid_mask]
    valid_sigmas = peak_n_sigmas[valid_mask]
    
    if len(valid_indices) == 0: return []

    print(f"            ℹ️  [Ranking Peaks] Found {len(valid_indices)} peaks with n_sigma > {cfg.SIGMA_THRESHOLD}.")

    # 3. Sort by significance
    sorted_order = np.argsort(valid_sigmas)[::-1]
    sorted_indices = valid_indices[sorted_order]
    top_indices = sorted_indices[:10]
    
    added_freqs = []

    for idx in top_indices:
        p_val = raw_power[idx]
        n_sigma = (p_val - noise_mean[idx]) / noise_std[idx]
        cand_freq = freqs[idx]
        cand_period = 1.0 / cand_freq
        
        if np.isnan(cand_period) or cand_period <= 0 or cand_period > max_allowed_period: continue
        is_duplicate = any(abs(cand_freq - f) < max(0.01 * f, 1e-5) for f in added_freqs)
        if is_duplicate: continue

        # Dynamic labeling
        ratio = cand_period / base_period
        label = "Peak"
        if abs(ratio - 1.0) < 0.05: label = "P"
        elif abs(ratio - 2.0) < 0.1: label = "2P"
        elif abs(ratio - 3.0) < 0.1: label = "3P"
        elif abs(ratio - 4.0) < 0.1: label = "4P"
        elif abs(ratio - 0.5) < 0.05: label = "P/2"
        else:
            rank_pow = list(sorted_indices).index(idx) + 1
            label = f"Peak_{rank_pow}"

        print(f"            ➕ Adding candidate: {label} ({cand_period:.4f}d, SNR={n_sigma:.2f})")

        quality = evaluate_period_quality(times, mags, cand_period)
        if any(np.isnan(v) for v in quality.values()): continue
            
        candidates.append({
            'period': cand_period, 'freq': cand_freq, 'label': label,
            'power': p_val, 'n_sigma': n_sigma, 'quality': quality
        })
        added_freqs.append(cand_freq)

    if not candidates: return []
    
    # --- Ranks Calculation ---
    metrics = {
        'n_sigma': np.array([c['n_sigma'] for c in candidates]),
        'string_length': np.nan_to_num(np.array([c['quality']['string_length'] for c in candidates]), nan=np.inf),
        'binned_variance': np.nan_to_num(np.array([c['quality']['binned_variance'] for c in candidates]), nan=-np.inf),
        'wrap_discontinuity': np.nan_to_num(np.array([c['quality']['wrap_discontinuity'] for c in candidates]), nan=np.inf),
        'smoothness': np.nan_to_num(np.array([c['quality']['smoothness'] for c in candidates]), nan=np.inf),
        'scatter': np.nan_to_num(np.array([c['quality']['within_bin_scatter'] for c in candidates]), nan=np.inf),
        'sharpness': np.nan_to_num(np.array([c['quality']['sharpness'] for c in candidates]), nan=-np.inf)
    }
    
    try:
        ranks = {}
        ranks['n_sigma'] = rankdata(-metrics['n_sigma'], method='average')
        ranks['string'] = rankdata(metrics['string_length'], method='average')
        ranks['binvar'] = rankdata(-metrics['binned_variance'], method='average')
        ranks['wrap'] = rankdata(metrics['wrap_discontinuity'], method='average')
        ranks['smooth'] = rankdata(metrics['smoothness'], method='average')
        ranks['scatter'] = rankdata(metrics['scatter'], method='average')
        ranks['sharp'] = rankdata(-metrics['sharpness'], method='average')
        
        for i, cand in enumerate(candidates):
            cand['rankings'] = {key: ranks[key][i] for key in ranks}
            cand['mean_rank'] = np.mean(list(cand['rankings'].values()))
            cand['median_rank'] = np.median(list(cand['rankings'].values()))
            cand['n_wins'] = sum(1 for r in cand['rankings'].values() if r == 1.0)
            cand['n_top2'] = sum(1 for r in cand['rankings'].values() if r <= 2.0)
        
        candidates.sort(key=lambda x: (-x.get('n_wins', -1), -x.get('n_top2', -1), x.get('median_rank', np.inf), x.get('mean_rank', np.inf)))
        
        # --- PRINT RANKING TABLE ---
        print("")
        print(f"🏆 Ranking analysis for base period {base_period:.4f}d (SNR Filters >{cfg.SIGMA_THRESHOLD}):")
        print("=" * 80)
        print("Sort criteria: 1) Wins  2) Top-2  3) Median rank  4) Mean rank")
        print("=" * 80)
        
        for i, cand in enumerate(candidates):
            icon = "✅" if i == 0 else "  "
            r = cand['rankings']
            q = cand['quality']
            
            print(f"{icon} {i+1}. {cand['label']:<8} = {cand['period']:.4f}d")
            print(f"      🏆 Wins: {cand['n_wins']}/7 | Top-2: {cand['n_top2']}/7 | Median Rank: {cand['median_rank']:.1f} | Mean Rank: {cand['mean_rank']:.2f}")
            print(f"      Rankings: SNR={r['n_sigma']:.1f} | StrLen={r['string']:.1f} | BinVar={r['binvar']:.1f} | Wrap={r['wrap']:.1f}")
            print(f"                Smooth={r['smooth']:.1f} | Scatter={r['scatter']:.1f} | Sharp={r['sharp']:.1f}")
            print(f"      Values:   SNR={cand['n_sigma']:.2f} | StrLen={q['string_length']:.4f} | BinVar={q['binned_variance']:.4f}")
            print("")
        print("=" * 80)

    except Exception as e:
        print(f"Error in ranking print: {e}")
        pass
        
    return candidates

# ============================
# BOKEH PLOTTING FUNCTIONS
# ============================

def phase_fold(times, mags, period):
    if np.isnan(period) or period <= 0: return np.array([]), np.array([]), np.array([]), 0.0
    phase = (times % period) / period
    sort_idx = np.argsort(phase)
    phase, mags = phase[sort_idx], mags[sort_idx]
    valid_mask = np.isfinite(phase) & np.isfinite(mags)
    phase, mags = phase[valid_mask], mags[valid_mask]
    n_points = len(phase)
    if n_points < 3: return phase, mags, mags, 0.0
    
    polyorder = 3
    window_size = max(int(0.1 * n_points), 5)
    if window_size <= polyorder: window_size = polyorder + 2
    if window_size % 2 == 0: window_size += 1
    window_size = min(window_size, n_points)
    if window_size % 2 == 0 and window_size > 1: window_size -=1
    polyorder = min(polyorder, window_size - 1)
    
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mags_smooth = savgol_filter(mags, window_length=window_size, polyorder=polyorder, mode="wrap")
    except: mags_smooth = mags
    
    if mags_smooth.size > 0:
        min_idx = np.argmin(mags_smooth)
        phase_shift = phase[min_idx]
        phase = (phase - phase_shift) % 1.0
        sort_idx = np.argsort(phase)
        return phase[sort_idx], mags[sort_idx], mags_smooth[sort_idx], phase_shift
    return phase, mags, mags, 0.0

def save_bokeh_plot(source_id, times, mags, freqs, power, threshold_curve, final_period, candidates, info_dict):
    """Generates and saves the interactive BOKEH plot."""
    top_candidates = candidates[:5] if candidates else []
    special_periods = []
    
    if info_dict.get('mp_alert'): special_periods.append(('mp_suggested', info_dict['mp_suggested_period']))
    if not np.isnan(info_dict.get('sl_period', np.nan)): special_periods.append(('sl_period', info_dict['sl_period']))
    
    periods_to_plot = []
    if not np.isnan(final_period): periods_to_plot.append(('FINAL', final_period))
    for cand in top_candidates:
        if not np.isclose(cand['period'], final_period):
            periods_to_plot.append((cand['label'], cand['period']))
    for label, p in special_periods:
        if not any(np.isclose(p, x[1]) for x in periods_to_plot):
            periods_to_plot.append((label, p))

    col_plots = []
    fap = info_dict.get('fap', 1.0)
    color_status = "green" if fap < 0.01 else "yellow" if fap < 0.2 else "red"

    for p_label, p_val in periods_to_plot:
        if np.isnan(p_val) or p_val <= 0: continue
        phase, mags_folded, mags_smooth, phase_shift = phase_fold(times, mags, p_val)
        if phase.size == 0: continue

        txt = f"ID: {source_id} | Type: {p_label} | P: {p_val:.6f} d | FAP: {fap:.4f} | Strength: {info_dict.get('n_sigma',0):.2f}σ"
        if info_dict.get('mp_alert') and p_label == 'FINAL': txt += " | ⚠️ MP Alert"
        
        header_bg = "green" if color_status == "green" else "orange" if color_status=="yellow" else "lightgray"
        bar = Div(width=800, height=20, background=header_bg, text=f"<b>{txt}</b>")

        # 1. Phase Folded Plot
        p1 = figure(title=f"Phase Folded (P={p_val:.6f}d)", width=800, height=300)
        phase2 = np.concatenate([phase, phase+1])
        mag2 = np.concatenate([mags_folded, mags_folded])
        p1.scatter(phase2, mag2, size=4, alpha=0.6, legend_label="Data")
        if mags_smooth.size == phase.size:
            mag_smooth2 = np.concatenate([mags_smooth, mags_smooth])
            ord_s = np.argsort(phase2)
            p1.line(phase2[ord_s], mag_smooth2[ord_s], color="red", line_width=2, legend_label="Smooth")
        p1.y_range.flipped = True
        p1.yaxis.axis_label = "Magnitude"
        p1.legend.click_policy = "hide"

        # --- Interpolation for Un-folded Model & Residuals ---
        t_grid = np.array([])
        mod_grid = np.array([])
        residuals = np.full_like(mags, np.nan)
        
        # Ensure unique phases for safe interpolation
        unique_phases, unique_indices = np.unique(phase, return_index=True)
        if len(unique_phases) > 3 and mags_smooth.size == phase.size:
            smooth_unique = mags_smooth[unique_indices]
            # Extend to boundaries to handle wrapping gracefully
            phase_ext = np.concatenate([unique_phases - 1.0, unique_phases, unique_phases + 1.0])
            smooth_ext = np.concatenate([smooth_unique, smooth_unique, smooth_unique])
            try:
                interp_model = interp1d(phase_ext, smooth_ext, kind='linear', bounds_error=False, fill_value='extrapolate')
                
                # High resolution time grid for smooth model overlay
                t_grid = np.linspace(times.min(), times.max(), min(5000, len(times)*10))
                p_grid = ((t_grid % p_val) / p_val - phase_shift) % 1.0
                mod_grid = interp_model(p_grid)
                
                # Evaluate model at actual observing times to calculate residuals
                orig_phase = ((times % p_val) / p_val - phase_shift) % 1.0
                model_mags = interp_model(orig_phase)
                residuals = mags - model_mags
            except Exception:
                pass

        # 2. Original LC + Model Plot
        p3 = figure(title=f"Original Light Curve + Smooth Model Overlaid", width=800, height=300)
        p3.scatter(times, mags, size=4, alpha=0.6, legend_label="Data")
        if len(t_grid) > 0:
            p3.line(t_grid, mod_grid, color="red", line_width=2, legend_label="Model")
        p3.y_range.flipped = True
        p3.xaxis.axis_label = "Time [d]"
        p3.yaxis.axis_label = "Magnitude"
        p3.legend.click_policy = "hide"

        # 3. Residuals Plot
        p4 = figure(title="Residuals (Data - Model)", width=800, height=200)
        if not np.all(np.isnan(residuals)):
            p4.scatter(times, residuals, size=4, color="purple", alpha=0.6)
            zero_span = Span(location=0, dimension='width', line_color='black', line_dash='dashed', line_width=2)
            p4.add_layout(zero_span)
        p4.y_range.flipped = True
        p4.xaxis.axis_label = "Time [d]"
        p4.yaxis.axis_label = "Delta Mag"

        # 4. Lomb-Scargle Plot
        p2 = figure(title="Lomb-Scargle + 3σ Threshold", width=800, height=300)
        periods_ls = 1.0 / freqs
        
        # Plot full range of periods 
        p2.line(periods_ls, power, color="navy", alpha=0.8, legend_label="Power")
        p2.line(periods_ls, threshold_curve, color="orange", line_width=2, line_dash="dashed", legend_label="3σ Threshold")
        
        for pp_lab, pp_val in periods_to_plot:
            c = "red" if pp_val == p_val else "green" if pp_lab == 'FINAL' else "gray"
            w = 2 if pp_val == p_val else 1
            s = Span(location=pp_val, dimension='height', line_color=c, line_width=w)
            p2.add_layout(s)

        p2.xaxis.axis_label = "Period [d]"
        p2.yaxis.axis_label = "Power"
        p2.legend.click_policy = "hide"

        col_plots.append(column(bar, p1, p3, p4, p2))

    if col_plots:
        layout = column(*col_plots)
        safe_id = str(source_id).replace('/','_')
        fname = os.path.join(cfg.OUT_DIR_PLOTS, f"ID_{safe_id}.html")
        output_file(fname)
        save(layout)

# ============================
# MAIN LOMB-SCARGLE ENGINE
# ============================

def find_ls_period_config_driven(times, mags, mags_err, source_id, sl_period=None):
    default_return = (np.nan, 0.0, False, 1.0, np.nan, 0.0, False, np.nan, 0.0, np.nan, False, np.nan, 0.0, np.nan, np.nan, None, 1.0, np.nan, False, np.nan)
    
    baseline = times.max() - times.min()
    if baseline <= 0 or len(times) < cfg.MIN_POINTS: return default_return
    
    print(f"Applying {cfg.DETREND_WINDOW_DAYS}-day moving average detrending...")
    
    # 1. Frequency Grid Setup
    eff_sampling = estimate_effective_sampling(times)
    
    if cfg.AUTO_FREQ_RANGE:
        min_p = max(3 * eff_sampling, 0.1) 
        max_p = 0.7 * baseline 
    else:
        min_p = cfg.MANUAL_MIN_PERIOD
        max_p = cfg.MANUAL_MAX_PERIOD

    print(f"      ℹ️ LS period limits set to: [{min_p:.2f}d, {max_p:.2f}d]")

    if min_p >= max_p: return default_return
    
    min_freq, max_freq = 1.0/max_p, 1.0/min_p

    # 2. Lomb-Scargle Calculation
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        freqs = np.linspace(min_freq, max_freq, cfg.FREQ_RESOLUTION)
        if freqs.size == 0: return default_return
        
        mags_centered = mags - np.mean(mags[np.isfinite(mags)])
        ls = LombScargle(times, mags_centered, dy=mags_err)
        power = ls.power(freqs)
        
        if np.all(np.isnan(power)) or np.all(power==0): return default_return

        # 3. Noise & FAP Estimation (Full Permutations)
        if cfg.N_PERMUTATIONS > 0:
            permuted = np.array([np.random.permutation(mags_centered) for _ in range(cfg.N_PERMUTATIONS)])
            perm_powers = np.array([LombScargle(times, p, dy=mags_err).power(freqs) for p in permuted])
            perm_powers = np.nan_to_num(perm_powers, nan=0.0)
            noise_mean = np.mean(perm_powers, axis=0)
            noise_std = np.std(perm_powers, axis=0)
            threshold_curve = noise_mean + 3 * noise_std
            
            best_power_raw = np.max(power)
            perm_max = perm_powers.max(axis=1)
            fap = np.sum(perm_max >= best_power_raw) / cfg.N_PERMUTATIONS
        else:
            return default_return

    # 4. Find Best Peak
    best_idx = np.nanargmax(power)
    best_freq = freqs[best_idx]
    best_period = 1.0 / best_freq
    best_power = power[best_idx]
    
    max_n_sigma = (best_power - noise_mean[best_idx]) / noise_std[best_idx]
    is_valid = max_n_sigma >= cfg.SIGMA_THRESHOLD
    
    # 5. Ranking Logic
    candidates = select_best_period_by_ranking(times, mags, best_period, freqs, power, noise_mean, noise_std)
    
    final_period = np.nan
    final_power = 0.0
    final_n_sigma = 0.0
    
    if not candidates:
        if is_valid:
            print(f"✅ Selected Peak_1 (Only significant peak found)")
            final_period, final_n_sigma, final_power = best_period, max_n_sigma, best_power
    else:
        winner = candidates[0]
        margin_txt = ""
        if len(candidates) > 1:
            second = candidates[1]
            diff_wins = winner['n_wins'] - second['n_wins']
            diff_med = second['median_rank'] - winner['median_rank']
            margin_txt = f"Margin vs 2nd ({second['label']}): +{diff_wins} Wins, +{diff_med:.1f} Median Rank"
        
        print(f"✅ Selected {winner['label']} = {winner['period']:.4f}d (Best in ranking)")
        if margin_txt: print(f"            ℹ️  [Ranking] {margin_txt}")
        
        final_period, final_n_sigma, final_power = winner['period'], winner['n_sigma'], winner['power']

    if sl_period is not None and not np.isnan(sl_period):
        print(f"\n🎯 Analysis for SL period {sl_period:.4f}d:")
        print(f"      Ratio Final/SL: {(final_period / sl_period):.4f}")
    
    print(f"\n📊 FAP (for {final_period:.4f}d): {fap:.6f} | FAP (max peak): {fap:.6f}")

    # 6. Multiple Peaks / Aliasing Check
    mp_res = (False, np.nan, 0, np.nan, np.nan, None, {})
    if not np.isnan(final_period):
        median_err = np.nanmedian(mags_err) if np.any(mags_err) else cfg.NOISE_FLOOR_MAG
        print(f"            ℹ️ [MP Check] Using threshold {median_err:.4f}.")
        mp_res = check_multiple_peaks_alert(times, mags, final_period, freqs, power, noise_mean, noise_std, median_err)
    
    mp_alert, mp_sugg, mp_diff, mp_dispP, mp_dispBest, mp_mult, _ = mp_res
    
    # 7. Final Statistics
    reduced_chi2 = np.nan 
    try:
        phase = (times % final_period) / final_period
        smooth = savgol_filter(mags[np.argsort(phase)], max(5, int(len(mags)/10)|1), 2, mode='wrap')
        res = mags[np.argsort(phase)] - smooth
        dof = max(1, len(times) - 5)
        chi2 = np.sum((res / mags_err[np.argsort(phase)])**2)
        reduced_chi2 = chi2 / dof
    except: pass
    
    p_error = calculate_period_fwhm(freqs, power, final_period)

    # 8. Plotting
    if cfg.MAKE_PLOTS and not np.isnan(final_period):
        info = {
            'fap': fap, 'n_sigma': final_n_sigma, 'mp_alert': mp_alert, 
            'mp_suggested_period': mp_sugg, 'sl_period': sl_period
        }
        try:
            save_bokeh_plot(source_id, times, mags, freqs, power, threshold_curve, final_period, candidates, info)
        except Exception as e:
            print(f"Error plotting {source_id}: {e}")

    # Return Result Tuple
    return (best_period, best_power, False, fap, final_period, final_power, False, np.nan, final_n_sigma, best_period, mp_alert, mp_sugg, mp_diff, mp_dispP, mp_dispBest, mp_mult, fap, reduced_chi2, False, p_error)

# ============================
# WORKER PROCESS
# ============================

def process_single_source(source_id, times, mags, errs, sl_period=np.nan):
    output_buffer = StringIO()
    old_stdout = sys.stdout
    sys.stdout = output_buffer
    
    final_res = None
    
    try:
        print("=" * 100)
        print(f"=== PROCESSING SOURCE ID {source_id} ===")
        print("=" * 100)
        print("")
        print(f"Ref SL Period: {sl_period:.4f}d" if not np.isnan(sl_period) else "Ref SL Period: N/A")
        print("")
        
        # 1. Clean NaNs
        mask = np.isfinite(times) & np.isfinite(mags) & np.isfinite(errs)
        times, mags, errs = times[mask], mags[mask], errs[mask]
        
        if len(times) < cfg.MIN_POINTS:
            print(f"⚠️ Insufficient valid points ({len(times)} < {cfg.MIN_POINTS}). Skipping.")
            sys.stdout = old_stdout
            return (output_buffer.getvalue(), None)

        # 2. Detrending (Crucial Step)
        original_median_mag = np.nanmedian(mags)
        mags_det, _ = moving_average_detrend(times, mags, cfg.DETREND_WINDOW_DAYS)
        mask_d = np.isfinite(mags_det)
        
        # Restore original magnitude baseline to detrended data to fix Y-axis scales in plots
        t_fin = times[mask_d]
        m_fin = mags_det[mask_d] + original_median_mag
        e_fin = errs[mask_d]

        if len(t_fin) >= cfg.MIN_POINTS:
            # 3. Period Search
            res_tuple = find_ls_period_config_driven(t_fin, m_fin, e_fin, source_id, sl_period=sl_period)
            
            (raw_p, raw_pow, conf_raw, fap_raw, fin_p, fin_pow, conf_fin, match_sl, n_sig, base_p, 
             mp_al, mp_sug, mp_dif, mp_dp, mp_db, mp_mul, fap_fin, chi2, fap_flg, p_err) = res_tuple
             
            final_res = (source_id, sl_period, raw_p, raw_pow, conf_raw, fap_raw,
                         fin_p, fin_pow, conf_fin, match_sl, n_sig, base_p,
                         mp_al, mp_sug, mp_dif, mp_dp, mp_db, mp_mul,
                         fap_fin, chi2, 1.0/cfg.N_PERMUTATIONS, fap_flg, p_err)
            
            # --- FOOTER ---
            print("\n" + "=" * 80)
            print(f"=== FINAL RESULTS FOR SOURCE ID {source_id} ===")
            print("=" * 80)
            print(f"SL period:              {sl_period:.6f} d")
            print(f"LS period (raw):        {raw_p:.6f} d (raw power={raw_pow:.4f})")
            print(f"LS corr base:           {base_p:.6f} d")
            print(f"LS period (FINAL):      {fin_p:.6f} d (SNR={n_sig:.2f})")
            print(f"FAP (max peak):         {fap_raw:.4f}")
            print(f"FAP (final period):     {fap_fin:.4f}")
            print("")
            print("--- FIT QUALITY ---")
            print(f"Reduced Chi-Square:     {chi2:.3f}")
            print("")
            print("--- MULTIPLE PEAKS CHECK (SNR + Dispersion) ---")
            print(f"Alert:                  {mp_al}")
            print(f"Dispersion P:           {mp_dp:.6f}")
            print(f"Best dispersion:        {mp_db:.6f}")
            print("=" * 80)
            print("\n\n")
            
        else:
            print(f"⚠️ Too few valid points after detrending (<{cfg.MIN_POINTS}). Skipping.")

    except Exception as e:
        print(f"❌ Error processing source {source_id}: {e}")
        import traceback
        traceback.print_exc()
        final_res = None
        
    sys.stdout = old_stdout
    return (output_buffer.getvalue(), final_res)

# ============================
# MAIN
# ============================
if __name__ == "__main__":
    if cfg.MAKE_PLOTS: os.makedirs(cfg.OUT_DIR_PLOTS, exist_ok=True)
    
    print(f"INITIALIZING GENERALIZED PERIOD SEARCH (PF^2)")
    print(f"   Config: {cfg.INPUT_FILE}")
    print(f"   Detrending: {cfg.DETREND_WINDOW_DAYS} days")
    if cfg.MAKE_PLOTS: print(f"   Plots will be saved in: {cfg.OUT_DIR_PLOTS}")
    
    # --- LOAD DATA ---
    try:
        if cfg.INPUT_FILE.lower().endswith('.fits') or cfg.INPUT_FILE.lower().endswith('.fit'):
            print(f"   Reading FITS file: {cfg.INPUT_FILE}")
            fits_table = Table.read(cfg.INPUT_FILE, format='fits')
            df = fits_table.to_pandas()
            
            # Decode byte-strings to standard strings
            for col in df.select_dtypes([object]).columns:
                try:
                    df[col] = df[col].str.decode('utf-8')
                except AttributeError:
                    pass
        else:
            print(f"   Reading CSV file: {cfg.INPUT_FILE}")
            df = pd.read_csv(cfg.INPUT_FILE, sep=cfg.CSV_SEP)
            
        # Dynamic Column Renaming based on Config
        df = df.rename(columns={
            cfg.COL_TIME: 't', 
            cfg.COL_MAG: 'y', 
            cfg.COL_ERR: 'dy', 
            cfg.COL_ID: 'id'
        })
        
        req_cols = ['t', 'y', 'dy', 'id']
        if not all(col in df.columns for col in req_cols):
            print(f"❌ Error: Config column names do not match data file. Found: {df.columns.tolist()}")
            sys.exit(1)
            
        print(f"   Loaded {len(df)} rows.")

        # Time Filters
        if cfg.TIME_MIN is not None: df = df[df['t'] >= cfg.TIME_MIN]
        if cfg.TIME_MAX is not None: df = df[df['t'] <= cfg.TIME_MAX]
        
        # Blacklist
        blacklist = set()
        if os.path.exists(cfg.BLACKLIST_FILE):
            with open(cfg.BLACKLIST_FILE) as f: blacklist = set(l.strip() for l in f)
            df = df[~df['id'].isin(blacklist)]
            
        # Reference Periods
        df_periods = None
        if os.path.exists(cfg.PERIODS_REF_FILE):
            try: df_periods = pd.read_csv(cfg.PERIODS_REF_FILE)
            except: pass

    except Exception as e:
        print(f"❌ DATA ERROR: {e}")
        sys.exit(1)
        
    # --- PREPARE TASKS ---
    grouped = df.groupby('id')
    tasks = []
    
    for sid, grp in grouped:
        times = grp['t'].values
        mags = grp['y'].values
        errs = grp['dy'].values
        
        sl = np.nan
        if df_periods is not None and 'ID' in df_periods.columns:
            row = df_periods[df_periods['ID'] == sid]
            if not row.empty and 'best_period' in row.columns:
                 sl = pd.to_numeric(row['best_period'].iloc[0], errors='coerce')
        
        tasks.append((sid, times, mags, errs, sl))
        
    print(f"Processing {len(tasks)} sources on {cfg.N_PROCESSES} cores...")
    
    # --- EXECUTE ---
    start_time = time.time()
    with multiprocessing.Pool(cfg.N_PROCESSES) as pool:
        results = list(tqdm(pool.starmap(process_single_source, tasks), total=len(tasks)))
    end_time = time.time()
    
    # --- EXPORT ---
    valid_data = [r[1] for r in results if r[1] is not None]
    logs = [r[0] for r in results]
    
    cols_csv = ["ID", "Ref_SL", "LS_Raw_P", "LS_Raw_Pow", "Conf_Raw", "FAP_Raw",
                "Final_Period", "Final_Pow", "Conf_Final", "Match_SL", "SNR_Final", "Base_Period",
                "MP_Alert", "MP_Sugg_P", "MP_Diff", "MP_Disp_P", "MP_Disp_Best", "MP_Mult",
                "Final_FAP", "Reduced_Chi2", "Sens_Lim", "Flag_FAP", "Err_Period"]
                
    if valid_data:
        pd.DataFrame(valid_data, columns=cols_csv).to_csv(cfg.OUTPUT_CSV, index=False, float_format='%.6g')
        print(f"\n📄 Results saved: {cfg.OUTPUT_CSV}")
        
    with open(cfg.OUTPUT_LOG, "w") as f: f.writelines(logs)
    print(f"Logs saved: {cfg.OUTPUT_LOG}")
    print(f"Finished in {end_time - start_time:.2f} s")