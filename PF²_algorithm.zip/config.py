# ===============================================================================================
# PHASE FOLDING & PERIOD FINDING ALGORTIHM (PF^2)
# GENERALIZED PERIOD SEARCH CONFIGURATION
# AUTHORs: ALESSANDRO SALVATORE TRAMUTO, ROSARIA (SARA) BONITO, LAURA VENUTI, MARCO MICELI
# YEAR: 2026
#
# DESCRIPTION:
# Configuration file for the generalized PF^2 algorithm. Contains all the
# parameters for data I/O, detrending, Lomb-Scargle processing, and ranking.
# ===============================================================================================

# --- 1. FILES AND I/O ---
# Path to your data. The algorithm automatically detects .csv or .fits extensions.
INPUT_FILE = "GaiaDR3_2163167051801848192_ZTF_g1_lc.fits"  
OUTPUT_CSV = "results_analysis.csv"                            # Output Table
OUTPUT_LOG = "log_analysis.txt"                                # Output Logs
BLACKLIST_FILE = "delete.txt"                                  # Optional: IDs to skip
PERIODS_REF_FILE = "stringlength_periods.csv"                  # Optional: Reference stringlength periods
MAKE_PLOTS = True                                              # Generate Bokeh HTML plots
OUT_DIR_PLOTS = "plots_output_generalized"                     # Directory for plots

# --- 2. COLUMN MAPPING ---
# Enter the EXACT column names from your input CSV or FITS table
COL_ID = "oid"         # Unique Identifier
COL_TIME = "mjd"       # Time (MJD, BJD, JD, etc.)
COL_MAG = "mag"        # Magnitude (must be magnitude, not flux)
COL_ERR = "magerr"     # Photometric Error
CSV_SEP = ","          # Separator for CSV (e.g., "," or "\t")     !!! [Ignored for FITS] !!!

# --- 3. DATA FILTERS ---
# Restrict data by time range (set to None to use all data)
TIME_MIN = None        # e.g., Start of campaign
TIME_MAX = None        # e.g., End of campaign
MIN_POINTS = 10        # Minimum valid points required to process a star

# --- 4. PHYSICS & DETRENDING ---
# Moving Average Window. MUST be larger than the max expected period.
# Keeps short-term variations while removing long-term trends.
DETREND_WINDOW_DAYS = 1000.0

# --- 5. LOMB-SCARGLE SETTINGS ---
FREQ_RESOLUTION = 250000    # Frequency grid steps (Higher = more precise, slower)
N_PERMUTATIONS = 5000      # Permutations for FAP (False Alarm Probability) and noise thresholds

# Search Space
AUTO_FREQ_RANGE = True     # If True, calculates limits based on baseline/sampling

# If False, uses these fixed limits:
MANUAL_MIN_PERIOD = 0.1    # Minimum search period (days)
MANUAL_MAX_PERIOD = 100.0  # Maximum search period (days)

# --- 6. RANKING & VALIDATION THRESHOLDS ---
# The algorithm finds all empirical peaks and evaluates them.
NOISE_FLOOR_MAG = 0.005    # (5 mmag). Improvements smaller than this are ignored.
SIGMA_THRESHOLD = 3.0      # Min statistical significance (n_sigma) required for ANY peak (from permutations)
TOLERANCE_RANKING = 0.15   # Tolerance (15%) for period matching logic

# --- 7. COMPUTING ---
N_PROCESSES = 1            # Number of CPU cores (batch processing)


# =============================================================================
# OUTPUT_CSV LEGEND
# =============================================================================
# 
# --- CSV COLUMNS EXPLANATION ---
# ID           : Unique identifier of the astronomical source.
# Ref_SL       : Reference period from external String Length catalog (if provided).
# LS_Raw_P     : Highest peak period from the raw Lomb-Scargle periodogram.
# LS_Raw_Pow   : Lomb-Scargle power value of the raw highest peak.
# Conf_Raw     : Boolean flag. True if LS_Raw_P matches the reference periods.
# FAP_Raw      : False Alarm Probability of the raw highest peak.
# Final_Period : The BEST period selected after empirical peak finding and ranking.
# Final_Pow    : Lomb-Scargle power of the Final_Period.
# Conf_Final   : Boolean flag. True if Final_Period matches reference periods.
# Match_SL     : Match indicator with SL reference period.
# SNR_Final    : Statistical significance (Sigma) of the Final_Period peak against the noise floor.
# Base_Period  : The primary period used as the base for ranking comparisons.
# MP_Alert     : Boolean. True if a harmonic (e.g., 2P, 3P) offers a significantly better phase dispersion fit.
# MP_Sugg_P    : Suggested alternative period if MP_Alert is True.
# MP_Diff      : Difference in phase dispersion between Final_Period and MP_Sugg_P.
# MP_Disp_P    : Phase dispersion score for the Final_Period (lower is better).
# MP_Disp_Best : Phase dispersion score for the best harmonic period found.
# MP_Mult      : The integer harmonic multiplier (e.g., 2, 3) of the suggested MP period.
# Final_FAP    : False Alarm Probability of the Final_Period.
# Reduced_Chi2 : Reduced Chi-Square of the smoothed model fit against the raw data.
# Sens_Lim     : Minimum measurable FAP based on N_PERMUTATIONS (e.g., 1/5000 = 0.0002).
# Flag_FAP     : Boolean. True if the Final_Period FAP is worse than the Raw FAP.
# Err_Period   : Estimated uncertainty of the Final_Period based on the peak's Full Width at Half Maximum (FWHM).
#
# --- GENERATED BOKEH PLOTS EXPLANATION ---
# 1. Phase Folded Plot:
#    Displays the photometric data folded over two phase cycles (0 to 2) using the Final_Period.
#    The red line is the smoothed mathematical model (Savitzky-Golay filter).
#
# 2. Original Light Curve + Smooth Model Overlaid:
#    Shows the original time-series data (Time vs. Magnitude). The red line is the 
#    phase-folded model "un-folded" and projected back into the actual observation times.
#
# 3. Residuals (Data - Model):
#    Displays the difference (Delta Mag) between the actual observed magnitudes and 
#    the un-folded model over time. Useful to spot remaining non-periodic signals, flares, or long-term trends.
#
# 4. Lomb-Scargle + 3-Sigma Threshold:
#    The full Lomb-Scargle periodogram (Period vs. Power). The dashed orange line represents the 
#    strict significance threshold (SIGMA_THRESHOLD) calculated via random permutations. 
#    Vertical lines mark the tested candidates, the final winner (Green), and references (Blue).
# =============================================================================